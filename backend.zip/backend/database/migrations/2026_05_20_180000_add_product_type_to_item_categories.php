<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasColumn('item_categories', 'product_type')) {
            Schema::table('item_categories', function (Blueprint $table) {
                $table->string('product_type', 100)->nullable()->after('name');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('item_categories', 'product_type')) {
            Schema::table('item_categories', function (Blueprint $table) {
                $table->dropColumn('product_type');
            });
        }
    }
};
