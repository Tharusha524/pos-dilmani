<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\PermissionService;
use App\Services\ReportService;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    public function __construct(
        private ReportService $reportService,
        private PermissionService $permissionService,
    ) {
    }

    public function index()
    {
        return response()->json([
            'success' => true,
            'data' => $this->reportService->listReportKeys(),
        ]);
    }

    public function show(Request $request, string $reportKey)
    {
        if (
            $this->permissionService->isMobileRequest($request)
            && !$this->permissionService->mobileCanViewReport($request->user(), $reportKey)
        ) {
            return response()->json([
                'success' => false,
                'message' => PermissionService::MOBILE_DENIED_MESSAGE,
                'code' => 'MOBILE_PERMISSION_DENIED',
            ], 403);
        }

        try {
            $filters = [
                'date_from' => $request->query('date_from'),
                'date_to' => $request->query('date_to'),
                'branch_id' => $request->query('branch_id'),
                'location' => $request->query('location'),
                'item_id' => $request->query('item_id'),
            ];

            return response()->json([
                'success' => true,
                'data' => $this->reportService->generate($request->user(), $reportKey, $filters),
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }
    }
}
