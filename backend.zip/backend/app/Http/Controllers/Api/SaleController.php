<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Bank;
use App\Services\CompanySettingService;
use App\Services\PermissionService;
use App\Services\SaleService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class SaleController extends Controller
{
    public function __construct(
        private SaleService $saleService,
        private CompanySettingService $companySettingService,
        private PermissionService $permissionService,
    ) {
    }

    /**
     * Mobile app only: refuse sale features the user's role has locked
     * (returns, exchange, hold, credit/cheque/bank/split payments).
     *
     * @param  array<string, mixed>  $payload
     */
    private function mobileSaleDenied(Request $request, array $payload): ?JsonResponse
    {
        if (
            !$this->permissionService->isMobileRequest($request)
            || $this->permissionService->mobileSaleDenial($request->user(), $payload) === null
        ) {
            return null;
        }

        return response()->json([
            'success' => false,
            'message' => PermissionService::MOBILE_DENIED_MESSAGE,
            'code' => 'MOBILE_PERMISSION_DENIED',
        ], 403);
    }

    public function index(Request $request)
    {
        try {
            $transactionType = $request->query('transaction_type');
            $location = $request->query('location');
            $dateFrom = $request->query('date_from');
            $dateTo = $request->query('date_to');
            $orderStatus = $request->query('order_status');
            $customerId = $request->query('customer_id');

            $result = $this->saleService->getAllForUser(
                $request->user(),
                is_string($transactionType) ? $transactionType : null,
                is_string($location) ? $location : null,
                is_string($dateFrom) ? $dateFrom : null,
                is_string($dateTo) ? $dateTo : null,
                is_string($orderStatus) ? $orderStatus : null,
                is_numeric($customerId) ? (int) $customerId : null,
            );

            return response()->json([
                'success' => true,
                'data' => $result['sales'],
                'returned_sale_ids' => $result['returned_sale_ids'] ?? [],
                'summary' => $result['summary'],
                'filters' => $result['filters'],
                'order_settings' => $result['order_settings'],
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }
    }

    public function posContext(Request $request)
    {
        try {
            return response()->json([
                'success' => true,
                'data' => $this->saleService->getPosContextForUser($request->user()),
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }
    }

    public function holdOrders(Request $request)
    {
        try {
            $location = $request->query('location');

            return response()->json([
                'success' => true,
                'data' => $this->saleService->getHoldOrdersForUser(
                    $request->user(),
                    is_string($location) ? $location : null,
                ),
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }
    }

    public function completeHold(Request $request, int $id)
    {
        try {
            $validated = $this->validateSale($request, false);
            if ($denied = $this->mobileSaleDenied($request, $validated)) {
                return $denied;
            }
            $sale = $this->saleService->completeHoldForUser($request->user(), $id, $validated);
            $receipt = $this->saleService->buildReceiptFromSale($request->user(), $sale);

            return response()->json([
                'success' => true,
                'message' => 'Hold order completed successfully',
                'data' => $sale,
                'receipt' => $receipt,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }
    }

    public function verifyRefundCard(Request $request)
    {
        try {
            $validated = $request->validate([
                'card_last4' => 'required|string|size:4',
            ]);
            $this->saleService->verifyRefundCardForUser($request->user(), $validated['card_last4']);

            return response()->json([
                'success' => true,
                'message' => 'Card verification passed',
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }
    }

    public function show(Request $request, int $id)
    {
        try {
            return response()->json([
                'success' => true,
                'data' => $this->saleService->getForUser($request->user(), $id),
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }
    }

    public function receipt(Request $request, int $id)
    {
        try {
            $language = $request->query('language');

            return response()->json([
                'success' => true,
                'data' => $this->saleService->getReceiptForUser(
                    $request->user(),
                    $id,
                    is_string($language) ? $language : null,
                ),
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }
    }

    public function store(Request $request)
    {
        try {
            $validated = $this->validateSale($request);
            if ($denied = $this->mobileSaleDenied($request, $validated)) {
                return $denied;
            }
            $user = $request->user();
            $sale = $this->saleService->createForUser($user, $validated);
            $receipt = $this->saleService->buildReceiptFromSale($user, $sale);

            return response()->json([
                'success' => true,
                'message' => 'Sale saved successfully',
                'data' => $sale,
                'receipt' => $receipt,
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }
    }

    public function update(Request $request, int $id)
    {
        try {
            $validated = $this->validateSale($request, false);
            if ($denied = $this->mobileSaleDenied($request, $validated)) {
                return $denied;
            }
            $sale = $this->saleService->updateForUser($request->user(), $id, $validated);

            return response()->json([
                'success' => true,
                'message' => 'Sale updated successfully',
                'data' => $sale,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }
    }

    public function destroy(Request $request, int $id)
    {
        try {
            $holdPin = $request->input('hold_pin');
            $this->saleService->deleteForUser(
                $request->user(),
                $id,
                is_string($holdPin) ? $holdPin : null,
            );

            return response()->json([
                'success' => true,
                'message' => 'Sale deleted successfully',
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }
    }

    public function nextSalesId(Request $request)
    {
        try {
            return response()->json([
                'success' => true,
                'data' => [
                    'sales_id' => $this->saleService->getNextSalesIdForUser($request->user()),
                ],
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }
    }

    private function validateSale(Request $request, bool $requireSalesId = true): array
    {
        $company = $this->companySettingService->getCompanyForUser($request->user());
        $companyId = (int) $company->id;

        // Some clients (e.g. the mobile app) send the bank's name instead of
        // its numeric ID — resolve it to the real ID before validating.
        $bankId = $request->input('bank_id');
        if ($bankId !== null && !is_numeric($bankId)) {
            $bank = Bank::where('company_id', $companyId)
                ->whereRaw('LOWER(name) = ?', [strtolower(trim((string) $bankId))])
                ->first();
            $request->merge(['bank_id' => $bank?->id]);
        }

        return $request->validate([
            'transaction_type' => 'nullable|string|max:20',
            'order_status' => 'nullable|string|in:completed,hold,quotation',
            'sales_type' => 'nullable|string|max:50',
            'pricing_mode' => 'nullable|string|in:retail,wholesale',
            'location' => 'nullable|string|max:100',
            'sale_date' => 'nullable|date',
            'sales_id' => ($requireSalesId ? 'required' : 'nullable').'|string|max:50',
            'customer_id' => 'nullable|integer|exists:customers,id',
            'customer_name' => 'nullable|string|max:255',
            'returned_from_sale_id' => 'nullable|integer|exists:sales,id',
            'sub_total' => 'nullable|numeric|min:0',
            'return_sub_total' => 'nullable|numeric|min:0',
            'discount' => 'nullable|numeric|min:0',
            'service_charge' => 'nullable|numeric|min:0',
            // No min:0 here — an Exchange bill's net_amount can be negative (refund due).
            // The server always recomputes the persisted net_amount from the line items
            // in OrderTransactionService::applySaleRules(), so this only validates shape.
            'net_amount' => 'nullable|numeric',
            'payment_method' => 'nullable|string|max:50',
            'amount_received' => 'nullable|numeric|min:0',
            'bank_id' => [
                'nullable',
                'integer',
                Rule::exists('banks', 'id')->where(fn ($query) => $query->where('company_id', $companyId)),
            ],
            // Freely-typed bank name (the mobile checkout screen's bank
            // field isn't a picker over real registered banks) — was
            // missing here entirely, so $request->validate() silently
            // stripped it before it ever reached SaleService.
            'bank_name' => 'nullable|string|max:100',
            'cheque_number' => 'nullable|string|max:50',
            // Split payment — part cash, part cheque, part credit, etc. on
            // one sale. Validated for shape only; SaleService::
            // resolvePaymentSplits enforces the amounts sum to the total.
            'payment_splits' => 'nullable|array',
            'payment_splits.*.payment_method' => 'required_with:payment_splits|string|max:50',
            'payment_splits.*.amount' => 'required_with:payment_splits|numeric|min:0.01',
            'payment_splits.*.cheque_number' => 'nullable|string|max:50',
            'payment_splits.*.bank_name' => 'nullable|string|max:100',
            'offer_applied' => 'nullable|boolean',
            'offer_id' => 'nullable|integer|exists:offers,id',
            'offer_promo_code' => 'nullable|string|max:50',
            'promo_code' => 'nullable|string|max:50',
            'refund_card_last4' => 'nullable|string|size:4',
            'hold_pin' => 'nullable|string|max:20',
            'notes' => 'nullable|string',
            'items' => 'nullable|array',
            'items.*.item_id' => 'nullable|integer|exists:items,id',
            'items.*.item_number' => 'nullable|string|max:100',
            'items.*.description' => 'required_with:items|string|max:500',
            'items.*.qty' => 'nullable|numeric|min:0.01',
            'items.*.unit_price' => 'nullable|numeric|min:0',
            'items.*.line_total' => 'nullable|numeric|min:0',
            'items.*.line_direction' => ['nullable', Rule::in(['sale', 'return'])],
            'items.*.imei_serial' => 'nullable|string|max:100',
            'items.*.batch_id' => 'nullable|string|max:100',
            'items.*.item_batch_id' => 'nullable|integer|exists:item_batches,id',
            'items.*.secondary_uom' => 'nullable|string|max:50',
            'items.*.secondary_uom_qty' => 'nullable|numeric|min:0',
            'items.*.additional_details' => 'nullable|string|max:2000',
        ], [
            'bank_id.exists' => 'The selected bank is invalid.',
        ]);
    }
}
