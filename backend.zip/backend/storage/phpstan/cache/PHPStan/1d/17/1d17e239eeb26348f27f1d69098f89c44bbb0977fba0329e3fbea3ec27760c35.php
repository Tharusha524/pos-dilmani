<?php declare(strict_types = 1);

// osfsl-F:/my work/POS/backend/vendor/composer/../laravel/framework/src/Illuminate/Macroable/Traits/Macroable.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6dd85b1e28b55ebeee678f9ca423dfb8375e1342bc42d8658da6321bdf97b3c0-8.2.12',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\support\\traits\\macroable' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));