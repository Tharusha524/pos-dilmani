<?php declare(strict_types = 1);

// osfsl-F:/my work/POS/backend/vendor/composer/../laravel/framework/src/Illuminate/Database/DetectsConcurrencyErrors.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-079c1bc39fd8ec081d5c3a138ac3aa0940ab4df18f18caf882eb75c836663bd9-8.2.12',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\database\\detectsconcurrencyerrors' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));