<?php declare(strict_types = 1);

// osfsl-F:/my work/POS/backend/vendor/composer/../laravel/framework/src/Illuminate/Database/Eloquent/Relations/Concerns/CanBeOneOfMany.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-38bc5d2eb7c99bc89747c75f7d17e019e2ccec21afb3441a35136977b66681bc-8.2.12',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\database\\eloquent\\relations\\concerns\\canbeoneofmany' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));